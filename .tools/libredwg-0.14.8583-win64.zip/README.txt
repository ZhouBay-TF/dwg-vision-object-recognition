LibreDWG - free implementation of the DWG file format

LibreDWG is a free C library to read and write DWG files.  This program is
part of the GNU project, released under the aegis of GNU.  It is licensed
under the terms of the GNU General Public License version 3 (or at you option
any later version).

DWG is a file format created in the 70's for the emerging CAD applications.
Currently it is the native file format of AutoCAD, a proprietary CAD program
developed by AutoDesk.

LibreDWG is a fork from LibDWG due to its usage of Esperanto, which we
think is not the best strategy for a free software project which aims
to get lots of contributors. LibreDWG is written in English. At the
moment our decoder (i.e. reader) is done, it can read all DWG
versions, just some very advanced R2010+ objects fail to read and are
skipped over. The writer is good enough for everything but R2007.
R2010-R2018 writing leads to CRC errors still. Among the
example applications we wrote using LibreDWG is a reader, a writer, a
rewriter (i.e. saveas), an initial SVG and Postscript conversion, dxf
and json converters, dwggrep to search for text, and dwglayer to print
the list of layers. More are in the pipeline. Please contact us if you
want to help.

The strings API is UTF-8 (WTF8 really, Windows UCS-2 has no surrogate
pairs), and encodes to the internal 8-bit or UCS-2 strings, depending
on the DWG version. Older DWG's are encoded in ~30 codepages, which we
convert to unicode/UTF-8.

We also maintain a diff document for our internal fixed ODA-5.4.1 spec
at doc/ODA-5.4.2-libredwg-diff.pdf

For security contact file a ticket or email the package maintainers:

Reini Urban <rurban AT cpan.org>

The now inactive founders and previous maintainers were:

Felipe Corrêa da Silva Sanches <juca AT members.fsf.org>
Rodrigo Rodrigues da Silva <pitanga AT members.fsf.org>
Hardeep Singh Rai <hardeep.rai AT gmail DOT com>

If you are looking for general information about the project, check our website:
http://www.gnu.org/software/libredwg/

== Building and installing the library ==

You need the following dependencies:
- Basic development tools (a C99 compiler like gcc/clang, make, autoconf, automake
  and libtool)

Optionally:

- libiconv: optional codepage conversion. without it's just a bit slower.
- libmimalloc: faster memory allocation, but usually not worth the hassle.
- pslib for dwg2ps: http://pslib.sourceforge.net/doc/pslib.html
- pcre2 with 8bit and 16bit libraries for dwggrep regexp support.
- gperf to update static hashes for several API's
  Only needed when you added objects or changed the dwg.spec significantly
- cmake, ninja
- ODAFileConverter from https://www.opendesign.com/guestfiles/oda_file_converter
  for doing cross-checks.
- xvfb-run from xvfb/xorg-x11-server-Xvfb for silencing ODAFileConverter popups.
- TeXinfo for building the docs
- SWIG 1.7+
- Python 2.7 or 3.x development headers (debian: python-dev; yum: python-devel)
  and the libxml2 python bindings.
- Perl 5 for the perl bindings
- doxygen to generate the reference manual
- jq to check json validity, and as dwgfilter backend
- shellcheck to check shell scripts
- rpmlint to check the spec validity
- jinq with some svg11 relaxng to check SVG validity.
  LaTeXML used to have a broken svg11-basic.rng. If so
  the zip from http://yupotan.sppd.ne.jp/relax-ng/svg11/ is correct.
  Needs to be installed into /usr/local/share/relaxng/svg11/
  sudo unzip ~/Downloads/svg11-relaxng-20060604.zip -d  /usr/local/share/relaxng/
  On Ubuntu I needed:
  apt install jing libjaxp1.3-java libbatik-java libavalon-framework-java
- mapbox/geojsonhint as geojson linter
  npm install -g @mapbox/geojsonhint
- geojson-validation as 2nd geojson fallback linter
  npm install -g geojson-validation
- shfmt to format shell scripts
- clang-format to format the C source code
- clang-tidy to check source code
- valgrind to find leaks and memory bugs
- timeout to help tests with large or hanging DWG's
- GNU parallel to speed up special tests (not the moreutils parallel!)
- picat to find unknown fields, a better prolog. http://picat-lang.org/

See INSTALL for generic instructions.  Basically, you do:

$ sh ./autogen.sh (if you checked out the source code from git)
$ ./configure [--disable-bindings] [--disable-docs] [--disable-shared]
$ make
$ make check
$ sudo make install

This builds and installs various files in the "installation dirs":
  $libdir     ($exec_prefix/lib)   -- library files (libredwg.*)
  $includedir ($prefix/include)    -- dwg.h dwg_api.h
  $libdir/pkgconfig                -- libredwg.pc
  $infodir    ($datarootdir/info)  -- LibreDWG.info

Use "./configure --help" to see a full list of options you can use to
customize the installation dirs.  Other options recognized by configure are:

  --enable-release

    Recommended for packagers and fuzzers. Disables all features
    which will not be enabled in official tarball releases. Like skipping
    unstable DWG features or objects, unknown DWG versions and objects.

  --enable-trace

    Enable runtime tracing via LIBREDWG_TRACE (default: no). When
    enabled, the environment variable LIBREDWG_TRACE is consulted on
    the first decode/encode attempt. Its value is an integer: 0 (no
    output) through 9 (full verbosity). Most tools do support a
    --verbosity|-v flag instead.

  --with-dxf-precision=rfc

   How many after-comma places in DXF doubles. 6 is the recommended
   value (e.g. use rfc), max and the default is 16.

  --with-geojson-precision=rfc

   How many after-comma places in GeoJSON doubles. 6 is the
   recommended value by RFC 7946, max and the default is 16.

  --disable-write

    Disable DWG write support (default: no).
    Write support only works for earlier versions until r2004.
    Rewriting most DWG's <= r2004 usually works fine.

  --disable-bindings

    Disable SWIG bindings for python and perl5.

  --disable-dxf

    Disables all in and out modules: DXF, DXFB, JSON, GeoJSON.

  --disable-json

    Disables the json in and out modules: JSON, GeoJSON.

  --disable-python

    Disable python bindings and tests.
    Related: --enable-python=python3.6
    to enforce a specific version.

  --enable-debug

    Activates support for unstable classes. For testing only.

  --enable-gcov

    Activates support for GNU gcov, test coverage reporting.

  --with-perl-install=vendor

   Where to install the perl bindings: vendor,arch,yes,no,site.
   Default is perl-install=site

== Windows ==

See the following scripts how we build on Windows:

* .github/workflows/main.yml: via msys/autotools, or cmake. gcc, clang-cl or VS2019.
* build-aux/smoke.sh: cross-compilation recipes
* build-aux/msys2.bat: msys2 deps
* .appveyor.yml: windows smoker

We do support mingw, clang-cl and Visual Studio >= 2019 via cmake.
stdint.h and inttypes.h must be available.
Pre-compiled Windows binaries are here: https://github.com/LibreDWG/libredwg/releases

== Example usage of the library ==

The programs and examples directories contains some application code
that uses our lib:

* dwgread -- A DWG reader supporting various output formats, such as
  JSON, DXF, DXFB, GeoJSON.

* dwgwrite -- A DWG writer supporting various input formats, such as DXF, DXFB, JSON.

* dxfwrite -- A DXF writer supporting various input formats, such as DWG, DXF, DXFB, JSON.

* dwg2dxf -- Converts a DWG to a DXF (ascii or binary, minimal or full), optionally
  under a different version. About 90% coverage.

* dxf2dwg -- Converts a ascii or binary DXF to a DWG (r2000 only so far).
  About 80% coverage.

* dwglayers -- Prints the list of layers in a DWG. Optionally with --extnames

* dwggrep -- Searches DWG files for a text string, via regular expressions.

* dwg2ps -- Opens a DWG file and outputs an PostScript file.  This code
  depends on the PSlib library.  On Debian-based systems this is usually
  available as a package named pslib-dev. This is very limited so far.

* dwgfilter -- Applies JSON filters via JQ. Either as structured grep,
  or to mass change certain values.

* dwg2SVG -- Opens a DWG file and outputs an SVG (Scalable Vector Graphics)
  file.  SVG is a W3C standard for 2d vector graphics.  You can open these
  files on several free software tools.  We recommend Inkscape, a free software
  vector graphics editor.  The dwg2SVG program will not handle 3d content
  from DWG since SVG only supports 2-dimensional images. Handles only some
  entities.

* dwgbmp -- Extracts the bmp thumbnail of a dwg file when it is available.

* dwgadd -- the easiest way to create DWG's (or DXF, JSON) from scratch or
  add entities to an existing DWG. It accepts a very simple file with commands
  to create entities or objects and set its properties.

* dwgrewrite -- Reads a DWG, writes it back under a different name and optionally
  under a different version (default r2000), and re-reads it back for confirmation.

* load_dwg -- This is a skeleton code, reading the DWG and adding an entity.
  Look there if you want to have a quickly glance on how to use the library.

* dwg2svg2 -- Another example how to use the DWG API, bypassing direct access to
  the DWG struct.

* xmlsuite -- an extensive example library to use XML to compare against prepared
  features is in the test/xmlsuite directory. It also features code to output entities
  in XML, but does not use the python bindings.

Copyright (C) 2009, 2010, 2015, 2018-2026 Free Software Foundation, Inc.

This library is free software, licensed under the terms of the GNU
General Public License as published by the Free Software Foundation,
either version 3 of the License, or (at your option) any later version.
You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
